from app import init_db
init_db()